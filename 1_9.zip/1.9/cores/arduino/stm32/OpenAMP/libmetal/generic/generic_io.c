#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/generic_io.c"

#endif /* VIRTIOCON */
