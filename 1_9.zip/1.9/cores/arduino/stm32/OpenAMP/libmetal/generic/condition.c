#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/condition.c"

#endif /* VIRTIOCON */
