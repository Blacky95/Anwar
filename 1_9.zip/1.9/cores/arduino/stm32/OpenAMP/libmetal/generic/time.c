#ifdef VIRTIOCON

#include "libmetal/lib/system/generic/time.c"

#endif /* VIRTIOCON */
