This repo contains some board variant for STM32duino. These variant are not based on exisiting commercial devkit but naked MCU.
They can be used as a starting point for making your own board variant.
See the variant directory for the list of already defined MCU.

These file must be copied in the /Document/Arduino/hardware/stm32/v.x.y/ directory.

More information related to this on https://www.disk91.com/2018/technology/hardware/stm32-and-arduino-working-with-a-custom-board
